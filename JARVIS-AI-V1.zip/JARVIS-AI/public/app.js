const messages = document.getElementById("messages");
const form = document.getElementById("chatForm");
const input = document.getElementById("messageInput");
const micButton = document.getElementById("micButton");
const voiceHint = document.getElementById("voiceHint");
const languageSelect = document.getElementById("languageSelect");
const memoryToggle = document.getElementById("memoryToggle");
const modeLabel = document.getElementById("modeLabel");

let language = "hi";
let recognition = null;
const MEMORY_KEY = "jarvis_memory_enabled";
const HISTORY_KEY = "jarvis_demo_history";

function addMessage(text, who = "assistant") {
  const row = document.createElement("div");
  row.className = `message ${who}`;
  if (who === "assistant") {
    const avatar = document.createElement("span");
    avatar.className = "avatar";
    avatar.textContent = "J";
    row.appendChild(avatar);
  }
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  row.appendChild(bubble);
  messages.appendChild(row);
  messages.scrollTop = messages.scrollHeight;
  if (memoryToggle.checked) {
    const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
    history.push({ who, text, at: Date.now() });
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(-50)));
  }
}

function speak(text) {
  if (!("speechSynthesis" in window)) {
    voiceHint.textContent = "इस ब्राउज़र में आवाज़ पढ़ने की सुविधा उपलब्ध नहीं है।";
    return;
  }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = language === "hi" ? "hi-IN" : "en-IN";
  const voices = window.speechSynthesis.getVoices();
  const preferred = voices.find(v => /male|david|ravi|hemant|google हिन्दी|google hindi/i.test(v.name));
  if (preferred) utterance.voice = preferred;
  utterance.rate = 0.95;
  window.speechSynthesis.speak(utterance);
}

async function sendMessage(message) {
  const clean = message.trim();
  if (!clean) return;
  addMessage(clean, "user");
  input.value = "";
  const waiting = document.createElement("div");
  waiting.className = "message assistant";
  waiting.innerHTML = '<span class="avatar">J</span><div class="bubble">सोच रहा हूँ...</div>';
  messages.appendChild(waiting);
  messages.scrollTop = messages.scrollHeight;
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: clean, language })
    });
    const data = await response.json();
    waiting.remove();
    if (!response.ok) throw new Error(data.error || "Request failed");
    addMessage(data.reply || "मुझे जवाब नहीं मिला।");
    modeLabel.textContent = data.mode === "ai" ? "AI ONLINE" : "DEMO ONLINE";
    speak(data.reply || "");
  } catch (err) {
    waiting.remove();
    addMessage(err.message || "सर्वर से कनेक्शन नहीं हो पाया।");
  }
}

form.addEventListener("submit", e => {
  e.preventDefault();
  sendMessage(input.value);
});
document.querySelectorAll("[data-prompt]").forEach(btn => {
  btn.addEventListener("click", () => sendMessage(btn.dataset.prompt));
});
document.getElementById("clearButton").addEventListener("click", () => {
  messages.replaceChildren();
  localStorage.removeItem(HISTORY_KEY);
  addMessage("चैट साफ कर दी गई है।");
});
document.getElementById("searchButton").addEventListener("click", () => {
  const q = input.value.trim();
  if (!q) {
    addMessage("पहले ऊपर सर्च बॉक्स में अपना सवाल लिखें, फिर Web Search दबाएँ।");
    return;
  }
  window.open("https://www.google.com/search?q=" + encodeURIComponent(q), "_blank", "noopener");
});

languageSelect.addEventListener("change", () => {
  language = languageSelect.value;
  voiceHint.textContent = language === "hi" ? "हिंदी आवाज़ चुनी गई है।" : "English voice selected.";
});
memoryToggle.checked = localStorage.getItem(MEMORY_KEY) === "true";
memoryToggle.addEventListener("change", () => {
  localStorage.setItem(MEMORY_KEY, String(memoryToggle.checked));
  if (!memoryToggle.checked) localStorage.removeItem(HISTORY_KEY);
});

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.onstart = () => { voiceHint.textContent = "सुन रहा हूँ... अब बोलिए।"; };
  recognition.onresult = event => {
    const transcript = event.results[0][0].transcript;
    input.value = transcript;
    sendMessage(transcript);
  };
  recognition.onerror = () => { voiceHint.textContent = "आवाज नहीं मिल पाई। माइक अनुमति और इंटरनेट जाँचें।"; };
  recognition.onend = () => { if (voiceHint.textContent.includes("सुन रहा")) voiceHint.textContent = "आप चाहें तो फिर से बोल सकते हैं।"; };
  micButton.addEventListener("click", () => {
    recognition.lang = language === "hi" ? "hi-IN" : "en-IN";
    recognition.start();
  });
} else {
  micButton.disabled = true;
  voiceHint.textContent = "इस ब्राउज़र में Speech Recognition सपोर्ट नहीं है। Chrome में खोलकर देखें।";
}

fetch("/api/health").then(r => r.json()).then(data => {
  modeLabel.textContent = data.mode === "ai" ? "AI ONLINE" : "DEMO ONLINE";
}).catch(() => { modeLabel.textContent = "OFFLINE"; });

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(() => {}));
}
