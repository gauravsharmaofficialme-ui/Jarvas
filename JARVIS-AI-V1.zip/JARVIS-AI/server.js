require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "30kb" }));
app.use(express.static(path.join(__dirname, "public")));

const demoReplies = [
  "जी, मैं J.A.R.V.I.S. हूँ। अभी मैं Free Demo Mode में काम कर रहा हूँ।",
  "समझ गया। मैं आपकी मदद कर सकता हूँ। असली AI API जोड़ने पर मेरे जवाब और अधिक उपयोगी होंगे।",
  "नमस्ते! बताइए, आज मैं आपकी किस काम में सहायता करूँ?",
  "यह सुविधा Demo में सीमित है। असली AI और सुरक्षित अनुमतियाँ जोड़कर इसे आगे बढ़ाया जा सकता है।"
];

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    assistant: "J.A.R.V.I.S.",
    mode: process.env.AI_API_KEY ? "ai" : "demo"
  });
});

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    const language = req.body?.language === "en" ? "en" : "hi";

    if (!message) return res.status(400).json({ error: "Message is required." });
    if (message.length > 4000) return res.status(413).json({ error: "Message is too long." });

    // Real AI mode is optional. The API key stays on the server, never in browser code.
    if (process.env.AI_API_KEY) {
      const base = (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
      const model = process.env.AI_MODEL || "gpt-4o-mini";
      const response = await fetch(`${base}/chat/completions`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${process.env.AI_API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model,
          messages: [
            {
              role: "system",
              content: "You are J.A.R.V.I.S., a helpful, safe assistant. Reply in Hindi unless the user writes in English. Do not claim you can control the phone or computer unless an enabled tool actually performs that action. Ask for confirmation before consequential actions."
            },
            { role: "user", content: message }
          ],
          temperature: 0.7
        })
      });

      if (!response.ok) {
        const detail = await response.text();
        console.error("AI provider error:", response.status, detail.slice(0, 500));
        return res.status(502).json({ error: "AI service अभी उपलब्ध नहीं है। बाद में फिर कोशिश करें।" });
      }
      const data = await response.json();
      const reply = data.choices?.[0]?.message?.content?.trim();
      return res.json({ reply: reply || "मुझे जवाब नहीं मिला।", mode: "ai" });
    }

    const lower = message.toLowerCase();
    let reply;
    if (/hello|hi|नमस्ते|नमस्कार|हेलो/.test(lower)) {
      reply = language === "en"
        ? "Hello! I am J.A.R.V.I.S. Free Demo. How can I help?"
        : "नमस्ते! मैं J.A.R.V.I.S. हूँ। बताइए, मैं आपकी क्या मदद करूँ?";
    } else if (/time|समय|बजे/.test(lower)) {
      reply = language === "en"
        ? `Your device time is ${new Date().toLocaleTimeString("en-IN")}.`
        : `आपके डिवाइस के अनुसार अभी समय ${new Date().toLocaleTimeString("hi-IN")} है।`;
    } else if (/date|तारीख|आज कौन/.test(lower)) {
      reply = language === "en"
        ? `Today's date is ${new Date().toLocaleDateString("en-IN")}.`
        : `आज की तारीख ${new Date().toLocaleDateString("hi-IN")} है।`;
    } else if (/search|खोज|ढूंढ|इंटरनेट/.test(lower)) {
      reply = language === "en"
        ? "Use the Web Search button below to search the internet."
        : "इंटरनेट पर खोजने के लिए नीचे Web Search बटन इस्तेमाल करें।";
    } else {
      reply = demoReplies[Math.floor(Math.random() * demoReplies.length)];
      if (language === "en") reply = "I am running in Free Demo mode. Connect an AI API later for full conversational answers.";
    }
    return res.json({ reply, mode: "demo" });
  } catch (error) {
    console.error("Chat error:", error);
    return res.status(500).json({ error: "कुछ गड़बड़ हुई। कृपया फिर कोशिश करें।" });
  }
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`J.A.R.V.I.S. running on port ${PORT}`);
});
